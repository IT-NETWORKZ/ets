import api from "./axios";

export const loginCandidate = (email, password) =>
  api.post("/log", { email, password });

export const loginAdmin = (email, password) =>
  api.post("/log", { email, password });

export const registerCandidate = (payload) =>
  api.post("/CandidateRegister", payload);

export const registerAdmin = (payload) =>
  api.post("/reg", payload);