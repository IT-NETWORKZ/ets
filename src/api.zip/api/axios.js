import axios from "axios";

const api = axios.create({
  baseURL: "https://localhost:44352/api/log",
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
  },
});

export default api;